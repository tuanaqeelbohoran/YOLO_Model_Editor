﻿www.getorgchart.com
GetOrgChart version 2.5.0
Installation:
	In your html document between the head tags include the following code, and then GetOrgChart will be installed:
	<script src="www.yourdomain.com/getorgchart/getorgchart.js"></script>
    <link href="www.yourdomain.com/getorgchart/getorgchart.css" rel="stylesheet" />

Dependencies:
	jQuery

Send us an email if you need assistance
	email: support@getorgchart.com

License:
	http://getorgchart/home/eula


Release Notes 2.5.2
	1. Fixed expand collapse in IE and Edge

Release Notes 2.5.1
	1. insertNodeEvent now you can set default node data

Release Notes 2.5.0
	1. Drag&Drop
	2. Fixed an issue with Edge expand collapse, move

Release Notes 2.4.91
	1. Mixed hierarchy, only the last children will be in vertical hierarchy

Release Notes 2.4.9
	1. New option: separationMixedHierarchyNodes

Release Notes 2.4.8
	1. If the second parent node is a neighbor to the node change the link connection start and end points

Release Notes 2.4.7
	1. Removed console.log

Release Notes 2.4.6
	1. Mixed Hierarchy Order

Release Notes 2.4.5
	1. Fixed an issue witd load from HTML table  and second parent relation column 

Release Notes 2.4.4
	1. Fixed export to image with no image box

Release Notes 2.4.3
	1. Fixed second parent relation
	2. Fixed export to image