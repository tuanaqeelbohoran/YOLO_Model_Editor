﻿Imports System
Imports System.IO
Imports System.IO.StreamReader
Imports System.IO.StreamWriter
Imports System.IO.StringReader
Imports System.IO.StringWriter
Imports System.Text
Imports LiveCharts
Imports LiveCharts.Charts
Public Class frmByakugan
    Private layers As New List(Of String)


    Private Sub btnExe_Click(sender As Object, e As EventArgs) Handles btnExe.Click


        Dim ofd As New OpenFileDialog()

        If ofd.ShowDialog() = DialogResult.OK Then

            Dim stream As System.IO.Stream
            stream = ofd.OpenFile()
            If Not (stream Is Nothing) Then

                Dim sr As New System.IO.StreamReader(stream)
                Console.WriteLine(sr.ReadToEnd())

                txtOpenPath.Text = ofd.FileName.ToString
                sr.Close()
                stream.Close()
            End If
        End If
        txtFileName.Text = IO.Path.GetFileNameWithoutExtension(txtOpenPath.Text)
        txtSavePath.Text = IO.Path.GetDirectoryName(txtOpenPath.Text)
        Dim CNN As String = txtOpenPath.Text
        layers.Clear()
        TreeView1.Nodes.Clear()
        Call ReadNet(CNN)
        Call DisplayTree(layers)
    End Sub

    Private Sub ReadNet(asFileName As String)
        Dim lsParamData As String = ""
        Using sr As StreamReader = New StreamReader(asFileName, System.Text.Encoding.GetEncoding("UTF-8"))

            lsParamData = sr.ReadLine()
            Do Until lsParamData Is Nothing
                If lsParamData.Contains("[") Or lsParamData.Contains("]") Then
                    layers.Add(lsParamData)
                Else
                    layers.Add(lsParamData)
                End If
                lsParamData = sr.ReadLine()
            Loop
        End Using
    End Sub




    Private Sub DisplayTree(ByRef list)
        For i = 0 To list.Count - 1
            Dim layer As String = layers.ElementAt(i)
            If layer.Contains("[") Or layer.Contains("]") Then
                TreeView1.Nodes.Add(layer)

            Else
                If Not layer = "" And Not layer.Contains("#") Then
                    Dim nodenum As Integer = TreeView1.Nodes.Count - 1
                    TreeView1.Nodes(nodenum).Nodes.Add(layer)
                End If

            End If

        Next
    End Sub


    Private Sub TreeView1_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles TreeView1.MouseDoubleClick
        Try
            TreeView1.LabelEdit = True
            TreeView1.SelectedNode.BeginEdit()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub TreeView1_AfterLabelEdit(sender As Object, e As NodeLabelEditEventArgs) Handles TreeView1.AfterLabelEdit
        layers.Clear()

        For i = 0 To TreeView1.Nodes.Count - 1
            layers.Add(TreeView1.Nodes(i).Text.ToString)
            Dim children As New List(Of String)
            children = GetChildren(TreeView1.Nodes(i))
            For j = 0 To children.Count - 1
                layers.Add(children.ElementAt(j))
            Next
        Next
    End Sub


    Function GetChildren(parentNode As TreeNode) As List(Of String)
        Dim nodes As List(Of String) = New List(Of String)
        GetAllChildren(parentNode, nodes)
        Return nodes
    End Function

    Sub GetAllChildren(parentNode As TreeNode, nodes As List(Of String))
        For Each childNode As TreeNode In parentNode.Nodes
            nodes.Add(childNode.Text)
            GetAllChildren(childNode, nodes)
        Next
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            Dim addindex As Integer = TreeView1.SelectedNode.Index + 1
            If Not TreeView1.SelectedNode.IsExpanded Then
                If TreeView1.SelectedNode.Nodes.Count = 0 Then
                    TreeView1.Nodes(addindex - 1).Nodes.Add("NewParam")
                Else
                    TreeView1.Nodes.Insert(addindex, "[]")
                End If
            ElseIf TreeView1.SelectedNode.IsExpanded Then
                TreeView1.Nodes(addindex - 1).Nodes.Add("NewParam")

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnDel_Click(sender As Object, e As EventArgs) Handles btnDel.Click
        Try
            Dim addindex As Integer = TreeView1.SelectedNode.Index

            TreeView1.Nodes.RemoveAt(addindex)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
            txtSavePath.Text = FolderBrowserDialog1.SelectedPath
        End If
    End Sub
End Class
